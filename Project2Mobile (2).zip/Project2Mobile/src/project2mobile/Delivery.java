
package project2mobile;
/**
 * Delivery class for the object used in transferring parts from one warehouse to another.
 * @author Josh
 */
public class Delivery {
    
    String partname;
    String Quantity;
    /**
     * Constructor for the object Delivery which is the two strings given for each line in delivery files.
     * @param partname is the name of the BikePart
     * @param Quantity is the number of BikeParts to be moved
     */
    public Delivery(String partname, String Quantity){
        this.partname = partname;
        this.Quantity = Quantity;
    }
    /**
     * getter for the partname.
     * @return returns partname.
     */
    public String getPn(){
        return partname;
    }
    /**
     * Getter for the quantity.
     * @return returns quantity.
     */
    public int getQ2(){
        return Integer.parseInt(Quantity);
    }
}
