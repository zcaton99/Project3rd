
package project2mobile;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
/**
 * Class that contains all logic for executing methods that are tied to buttons and text fields.
 * @author Josh
 */
public class FXMLDocumentController {
    
    @FXML
    private Button button;
    @FXML
    private TextField cmdTextField;   
    @FXML
    private TextField cmdTextField2; 
    @FXML
    private TextField cmdTextField3;
    @FXML
    private TextArea displayTextArea;
    @FXML
    private Label label;
    @FXML 
    private TextField cmdTextFieldDeliver;
    @FXML 
    private TextField cmdTextFieldEnter;
    @FXML 
    private TextField cmdTextFieldname;
    @FXML 
    private TextField cmdTextFieldnum;
    @FXML 
    private TextField cmdTextFieldprice;
    @FXML 
    private TextField cmdTextFieldsale;
    @FXML 
    private TextField cmdTextFieldonSale;
    @FXML 
    private TextField cmdTextFieldquantity;
    @FXML
    private TextField cmdTextFieldSell;
    @FXML
    private TextField cmdTextFieldAdd;
    @FXML
    private TextField cmdTextFieldentername;
    @FXML
    private TextField cmdTextFieldsellname;
    
    String whName;
    String whFile;
    private static ArrayList<BikePart> bpDS = new ArrayList<>();
    private static ArrayList<BikePart> give = new ArrayList<>();
    private static ArrayList<BikePart> take = new ArrayList<>();
    public static ArrayList<String> pns = new ArrayList<>();
    public static ArrayList<String> pqs = new ArrayList<>();
    public static ArrayList<Delivery> deliv = new ArrayList<>();
    
/**
 * readBPDS reads in the initial warehouse data set from a file given by the user.
 * It also displays all BikeParts in the warehouse and denotes what each value is.
 * @param event
 * @throws FileNotFoundException
 * @throws IOException 
 */
            @FXML
        private void readBPDS(ActionEvent event) throws FileNotFoundException, IOException{  
        String s = cmdTextField.getText();
        File f = new File(s);
        displayTextArea.appendText("______________________________________________________________________________________"+"\n");
        try (BufferedReader reader = new BufferedReader(new FileReader(f))) { //reads the file given by the user in the first textfield
            String line;
            while((line = reader.readLine()) != null){
                String[] pa = line.split(",");
                int result = Integer.parseInt(pa[1]);
                double result2 = Double.parseDouble(pa[2]);
                double result3 = Double.parseDouble(pa[3]);
                Boolean result4 = Boolean.valueOf(pa[4]);
                int result5 = Integer.parseInt(pa[5]);
                BikePart b = new BikePart(pa[0],result,result2,result3,result4,result5); 
            
                BikePart found = findByName(pa[0]);
                if (findByName(pa[0]) == null){         //ensures that bikeparts with unique names are added to array               
                    bpDS.add(b);
                }
                else {                              //doesn't actually affect file, as no prints are made, only displays and initializes BPDS.
                    found.setPrice(b.getPrice());    
                    found.setSalesPrice(b.getSale());
                    found.setonSale(b.getonSale());
                    found.setQuantity(b.getQuantity());
                }  
                displayTextArea.appendText("Part Name: "+pa[0]+","+" Part Number: "+ result+","+" Price: $"+ result2+","+" Sales Price: $" + result3+","+" On Sale: " +result4+","+ " Quantity: " +result5+"\n");
            }
        }
    }
        /**
         * updateBPDS updates the existing warehouse data set with new parts from another text file given by the user, and if parts already exist, it will update the parts' attributes if any changes have been made.
         * It also displays what parts were added from the file given.
         * @param event
         * @throws FileNotFoundException
         * @throws IOException 
         */
        @FXML
        private void updateBPDS(ActionEvent event) throws FileNotFoundException, IOException{  
        String s = cmdTextField3.getText();
        File f = new File(s);
        String ss = cmdTextField.getText();
        File ff = new File(ss);
        displayTextArea.appendText("______________________________________________________________________________________"+"\n");
        displayTextArea.appendText("Updated " + ss + " with below from "+s+":\n");
        try (BufferedReader reader = new BufferedReader(new FileReader(f))) { //reads text file from user given text in 2nd textfield (topright)
            String line;
            while((line = reader.readLine()) != null){
                String[] pa = line.split(",");
                int result = Integer.parseInt(pa[1]);
                double result2 = Double.parseDouble(pa[2]);
                double result3 = Double.parseDouble(pa[3]);
                Boolean result4 = Boolean.valueOf(pa[4]);
                int result5 = Integer.parseInt(pa[5]);
                BikePart b = new BikePart(pa[0],result,result2,result3,result4,result5); 
            
                BikePart found = findByName(pa[0]);
                if (findByName(pa[0]) == null){         //ensures that bikeparts with unique names are added to array                
                    bpDS.add(b);
                }
                else {                              //if a bikepart already exists and is being added again, it will update the attributes from update file.
                    found.setPrice(b.getPrice());    
                    found.setSalesPrice(b.getSale());
                    found.setonSale(b.getonSale());
                    found.setQuantity(b.getQuantity());
                    displayTextArea.appendText(found.toString());
                }  
            
                PrintWriter writer = new PrintWriter(ff, "UTF-8");         //writes to the original file in the FIRST text box, not 2nd 
                for (BikePart bp : bpDS)          
                    writer.println(bp.toString().replace(" ", ","));         
                writer.close();
                displayTextArea.appendText("Part Name: "+pa[0]+","+" Part Number: "+ result+","+" Price: $"+ result2+","+" Sales Price: $" + result3+","+" On Sale: " +result4+","+ " Quantity: " +result5+"\n");
            }
        }
    }
    /**
     * findByName compares all BikeParts in the warehouse data set and returns a BikePart if its name is equal to the name given.
     * @param name
     * @return returns BikePart b 
     */        
    private static BikePart findByName(String name){
        for (BikePart b : bpDS)
            if (b.getName().equals(name))  
                    return b;
        return null;
    }
    /**
     * findByNamegive performs the same functionality as findByName, except it uses the giving warehouse's data set to compare by.
     * @param name
     * @return BikePart b
     */
        private static BikePart findByNamegive(String name){
        for (BikePart b : give)
            if (b.getName().equals(name))  
                    return b;
        return null;
    }       
    /**
     * Displays a specific BikePart by comparing user input to BikePart names.
     * @param event 
     */     
        @FXML
    public void displayButtonMethod(ActionEvent event) {
        String s = cmdTextField2.getText();
        
        for (BikePart bp : bpDS)        //if user wishes to display a part from a different WH, must read in the WH file to change BPDS    
            if (bp.getName().equals(s)){  
                displayTextArea.appendText("______________________________________________________________________________________"+"\n");
                if(bp.getonSale() == true)
                    displayTextArea.appendText("Part Name: "+bp.getName()+","+" Current Price: $" + bp.getSale()+"\n");
                else
                    displayTextArea.appendText("Part Name: "+bp.getName()+","+" Current Price: $" + bp.getPrice()+"\n");
            }           
                 
    }
    /**
     * Allows user to input a new BikePart with attributes set by the user.
     * @param event
     * @throws IOException 
     */
        @FXML
    public void EnterButtonMethod(ActionEvent event) throws IOException {   //can enter to any WH so long as file name is in lefthand textbox, (does not have to be read in) 
        String s = cmdTextFieldentername.getText();
        File f = new File(s); 
        Scanner in = new Scanner(System.in);
        String pn = cmdTextFieldname.getText();
        int partnum = Integer.parseInt(cmdTextFieldnum.getText());
        double partprice = Double.parseDouble(cmdTextFieldprice.getText());
        double saleprice = Double.parseDouble(cmdTextFieldsale.getText());          //assigning part attributes to user input from textfields
        boolean sale = Boolean.parseBoolean(cmdTextFieldonSale.getText());
        int quant = Integer.parseInt(cmdTextFieldquantity.getText());
        BikePart bpaddition = new BikePart(pn,partnum,partprice,saleprice,sale,quant);
        bpDS.add(bpaddition);
        
        displayTextArea.appendText("______________________________________________________________________________________"+"\n");
        displayTextArea.appendText("Part Added" +"\n");
                        
        PrintWriter out = new PrintWriter(new FileWriter(f, true)); //writes to file to ensure new part stays      
        for (BikePart bp : bpDS) 
            out.println(bp.toString().replace(" ", ",")); // uses BikePart toString() but replaces the spaces with commas
        out.close(); 
    }
    /**
     * method used in converting ints to characters for use in addSalesVan method.
     * @param i
     * @return returns a character corresponding to numbers.
     */
    private String getCharForNumber(int i) {
        return i > 0 && i < 27 ? String.valueOf((char)(i + 64)) : null;
    }
    int i = 0;
    /**
     * Creates a new file with the name salesVan(A-Z).
     * It iterates through letters each time the add button is clicked, and will still work if the Van already exists.
     * In the event that a van already exists, the user will be prompted to continue clicking until the iterator has reached a letter that has yet to be used. 
     * @param event
     * @throws IOException 
     */
        @FXML
    private void addSalesVan(ActionEvent event) throws IOException{ //can improve by creating a .exists() boolean for filenames, and if it does continue adding to i. This way user wouldn't ahve to continue clicking in the event that a can already exists.

        try {
            i++;
	    File file = new File("SalesVan"+getCharForNumber(i)+".txt");        //creates a new file with an iterator of A-Z ot differentiate names of subsequent files
	    if (file.createNewFile()){
                displayTextArea.appendText("SalesVan" +getCharForNumber(i)+ ".txt File is created!"+"\n");
	    }else{
                displayTextArea.appendText("Van already exists, continue adding until iterator reaches unused number."+"\n");
	    }               
        }
        catch (IOException e) {
	      e.printStackTrace();
        }
    }
    
    @FXML
    private void addSalesVan2(ActionEvent event) throws IOException{ //can improve by creating a .exists() boolean for filenames, and if it does continue adding to i. This way user wouldn't ahve to continue clicking in the event that a can already exists.
        String s = cmdTextFieldAdd.getText();
        File f = new File(s+".txt");
        try {
            i++;
	    File file = new File(s+".txt");        //creates a new file with an iterator of A-Z ot differentiate names of subsequent files
	    if (file.createNewFile()){
                displayTextArea.appendText(s+ ".txt File is created!"+"\n");
	    }else{
                displayTextArea.appendText("Van already exists, try a different name."+"\n");
	    }               
        }
        catch (IOException e) {
	      e.printStackTrace();
        }
    }
    
     boolean ex; // going to check if the warehouse files exist
     boolean ex2;
     /**
      * Transfers BikeParts from one warehouse file to another while decrementing from the giving file and adding only the amount denoted by a delivery file.
      * @param event
      * @throws FileNotFoundException
      * @throws IOException 
      */
        @FXML
    private void transferBP (ActionEvent event) throws FileNotFoundException, IOException{
        
        String s = cmdTextFieldDeliver.getText(); // delivery file
        File f = new File(s);
        BufferedReader deliveryReader = new BufferedReader(new FileReader(f)); //reader for delivery file   
        String line;
        String line2;
        String giver;
        String receiver;
        String pn = " ";
        String pq;
        String first;
        
        String[] pa = {"should NOT see"};
        String firstresult = "Should NOT see";
        int result = 89;
        double result2 = 89;
        double result3 = 89;
        Boolean result4 = false;
        int result5 = 89;
        
        ArrayList<String> givernames = new ArrayList<>();
                
        first = deliveryReader.readLine(); //first line of document 
        String[] giverec = first.split(","); //splits only first line
        giver = giverec[0]; //first word of first line, (warehouse giving parts)
        receiver = giverec[1];// second word of first line, (warehouse receiving parts)
        displayTextArea.appendText("\n"+ "Giver file: "+giver + " --- Receiver file: "+ receiver+"\n");
        
        while((line = deliveryReader.readLine()) != null){
            String[] entries = line.split(",");
            pn = entries[0]; //first word in each subsuquent line, (partname)
            pq = entries[1]; //2nd word in each subsequent line, (quantity)        
            pns.add(pn);
            pqs.add(pq);
            Delivery de = new Delivery(pn, pq);
            deliv.add(de);
        }
        
        BikePart b2 = new BikePart("shouldntSee",1,2,3,true,10);
        File giverfile = new File(giver+".txt");
        File recfile = new File(receiver+".txt");

        ex = giverfile.exists();
        ex2 = recfile.exists();       
        
        if(ex == true && ex2 == true){
            BufferedReader giveReader = new BufferedReader(new FileReader(giverfile)); 
            BufferedReader recReader = new BufferedReader(new FileReader(recfile));   
            while((line2 = giveReader.readLine()) != null){
                pa = line2.split(",");
                firstresult = pa[0];
                result = Integer.parseInt(pa[1]);
                result2 = Double.parseDouble(pa[2]);
                result3 = Double.parseDouble(pa[3]);
                result4 = Boolean.valueOf(pa[4]);
                result5 = Integer.parseInt(pa[5]);
                BikePart b = new BikePart(pa[0],result,result2,result3,result4,result5); 
                givernames.add(firstresult);
                for(Delivery it : deliv){
                    if((it.getPn()).equals(pa[0])){      //for every part in the delivery file, if it matches a part in the giver file
                        b2 = new BikePart(pa[0],result,result2,result3,result4,(it.getQ2())); //quantity of part is decremented by quantity in delivery file
                    }
                }
                    if(recReader.readLine() == null){    //if the receiving file is blank, it will add parts as long as the receiving arraylist contains the bikepart                       
                        if(!take.contains(b2)){
                            take.add(b2);
                        }
                    }
            give.add(b); 
            for(Delivery it : deliv){               
                if((it.getPn()).equals(pa[0])){ 
                    BikePart found = findByNamegive(pa[0]);
                    found.setQuantity(b.getQuantity()-it.getQ2());           
                    }
                }           
            }

            while((line = recReader.readLine()) != null){ 
                String[] pa2 = line.split(",");              
                int rresult = Integer.parseInt(pa2[1]);      
                double rresult2 = Double.parseDouble(pa2[2]);
                double rresult3 = Double.parseDouble(pa2[3]);
                boolean rresult4 = Boolean.valueOf(pa2[4]);
                int rresult5 = Integer.parseInt(pa2[5]);
                
                BikePart b = new BikePart(pa2[0],rresult,rresult2,rresult3,rresult4,rresult5);
                
                for(Delivery it : deliv){
                    if((it.getPn()).equals(pa2[0])){
                        b.setQuantity(rresult5+it.getQ2());
                        displayTextArea.appendText("contains object");
                        //take.add(b);
                        }
                    if(givernames.contains(it.getPn()) && !it.getPn().equals(pa2[0])){
                        displayTextArea.appendText("new object!");
                        BikePart b7 = new BikePart(it.getPn(),rresult,rresult2,rresult3,rresult4,it.getQ2());
                        take.add(b7);
                    }
                }               
            }            
            PrintWriter takewriter = new PrintWriter(recfile, "UTF-8");         
            for (BikePart bp : take)          
                takewriter.println(bp.toString().replace(" ", ","));         
            takewriter.close();
            
            PrintWriter giverwriter = new PrintWriter(giverfile, "UTF-8");         
            for (BikePart bp : give)          
                giverwriter.println(bp.toString().replace(" ", ","));         
            giverwriter.close();
            
            displayTextArea.appendText("\n"+"give: "+give.toString());
            displayTextArea.appendText("\n"+"take: "+take.toString());
            }

        else
            displayTextArea.appendText("One or more of the files given in the delivery file do not exist, either add Vans or manually enter new files."+"\n"); 
        give.clear();
        take.clear();
    }
    /**
     * Sorts all BikeParts in the current BPDS by part name.
     * @param event
     * @throws FileNotFoundException
     * @throws UnsupportedEncodingException 
     */
        @FXML
    void SortButtonMethod(ActionEvent event) throws FileNotFoundException, UnsupportedEncodingException { //WH that is sorted must be read in, using first text box
        String s = cmdTextField.getText(); 
        File f = new File(s);
        Collections.sort(bpDS, (p1, p2) -> p1.getName().compareTo(p2.getName()));
        displayTextArea.appendText("______________________________________________________________________________________"+"\n");
        for(BikePart bp : bpDS){
            displayTextArea.appendText("Part Name: "+bp.getName()+","+" Part Number: "+ bp.getNumber()+","+" Price: $"+ bp.getPrice()+","+" Sales Price: $" + bp.getPrice()+","+" On Sale: " +bp.getonSale()+","+ " Quantity: " +bp.getQuantity()+"\n");
            
        }
        PrintWriter writer = new PrintWriter(f, "UTF-8");         
        for (BikePart bp : bpDS)          
            writer.println(bp.toString().replace(" ", ","));         
        writer.close();   
    }
    /**
     * Sorts all BikeParts in the current BPDS by part number.
     * @param event
     * @throws FileNotFoundException
     * @throws UnsupportedEncodingException 
     */
        @FXML
    void SortButtonMethod2(ActionEvent event) throws FileNotFoundException, UnsupportedEncodingException { //WH that is sorted must be read in, using first text box
        String s = cmdTextField.getText(); 
        File f = new File(s);
        Collections.sort(bpDS, (BikePart p1, BikePart p2) -> p1.getNumber() - p2.getNumber());
        displayTextArea.appendText("______________________________________________________________________________________"+"\n");
        for(BikePart bp : bpDS)
            displayTextArea.appendText("Part Name: "+bp.getName()+","+" Part Number: "+ bp.getNumber()+","+" Price: $"+ bp.getPrice()+","+" Sales Price: $" + bp.getPrice()+","+" On Sale: " +bp.getonSale()+","+ " Quantity: " +bp.getQuantity()+"\n");
        
        PrintWriter writer = new PrintWriter(f, "UTF-8");         
        for (BikePart bp : bpDS)          
            writer.println(bp.toString().replace(" ", ","));       
        writer.close();   
    }
    /**
     * Allows the user to sell a BikePart from the file in the first text box by inputting the part's partnumber.
     * It will decrement the quantity and also display the date/time the part was sold and at the current price. 
     * @param event 
     */
        @FXML
    void SellButtonMethod(ActionEvent event){       //can sell from any WH so long as file name is in lefthand textbox, (does not have to be read in)
        String s = cmdTextFieldsellname.getText(); 
        File f = new File(s);
        int soldpart = Integer.parseInt(cmdTextFieldSell.getText());
                    try (BufferedReader reader = new BufferedReader(new FileReader(f))) {
                        ArrayList<BikePart> bpArray2 = new ArrayList<>();
                        String line;
                    
                        while((line = reader.readLine()) != null){
                            String[] entries = line.split(",");
                            int result = Integer.parseInt(entries[1]);
                            double result2 = Double.parseDouble(entries[2]);
                            double result3 = Double.parseDouble(entries[3]);
                            Boolean result4 = Boolean.valueOf(entries[4]);
                            int result5 = Integer.parseInt(entries[5]);
                        
                            if(soldpart==result){
                                DateFormat df = new SimpleDateFormat("MM/dd/yy HH:mm:ss");  
                                Calendar calobj = Calendar.getInstance();                   //getting date/time
                    
                                result5 = result5-1;            //decrementing quantity of part
                                if(result4 = true)              //Displays sales price if onSale, and regular price if not on sale.
                                    displayTextArea.appendText(entries[0] + " sold for $" + result2 + " at "+ df.format(calobj.getTime())+ "\n");
                                else{   
                                    displayTextArea.appendText(entries[0] + " sold for $" + result3 + " at "+ df.format(calobj.getTime())+ "\n");
                                }
                            } 
                            BikePart bp = new BikePart(entries[0],result,result2,result3,result4,result5);
                            bpArray2.add(bp);  //adding back the parts to the array after they have been altered.   
                    }

                    PrintWriter writer = new PrintWriter(f, "UTF-8");       
                    for (BikePart bp : bpArray2)
                        writer.println(bp.toString().replace(" ", ",")); 
                    writer.close();    
                } 

                catch(FileNotFoundException fnfe){
                    System.out.println(fnfe.getMessage());       
                } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }          
    }
    /**
     * Exits the program.
     * @param event 
     */
        @FXML
    void QuitButtonMethod(ActionEvent event) {    
        System.exit(0);
    }
}       
  