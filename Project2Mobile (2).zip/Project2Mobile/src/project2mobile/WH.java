
package project2mobile;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
/**
 * WH class for determining which warehouses are tied to what files.
 * @author Josh
 */
public class WH {
    
    public String whName;
    public String whFile;
    public static ArrayList<BikePart> bpwh = new ArrayList<>(); 
    /**
     * WH constructor sets the WH objects to consist of String whName and String whFile.
     * @param whName is the name of the warehouse.
     * @param whFile is the name of the file.
     */
    public WH(String whName,String whFile){
        
        this.whName = whName;
        this.whFile = whName+".txt";
        
    }
    /**
     * Method for returning an arraylist of Strings that represent each part of the BikeParts in a WH.
     * @return returns an array of strings that represent each part of the BikeParts in a WH.
     * @throws FileNotFoundException
     * @throws IOException 
     */
    public ArrayList<String> getInventory() throws FileNotFoundException, IOException{      
        BufferedReader reader = new BufferedReader(new FileReader(whFile)); 
        ArrayList<String> Array2 = new ArrayList<>();
        String sumentries = " ";
        String line;
                    
        while((line = reader.readLine()) != null){
            String[] entries = line.split(",");
            int result = Integer.parseInt(entries[1]);
            double result2 = Double.parseDouble(entries[2]);
            double result3 = Double.parseDouble(entries[3]);
            Boolean result4 = Boolean.valueOf(entries[4]);
            int result5 = Integer.parseInt(entries[5]);
            sumentries = (entries[0]+","+result+","+result2+","+result3+","+result4+","+result5);
            //BikePart bp = new BikePart(entries[0],result,result2,result3,result4,result5);
            Array2.add(sumentries);
        }
        return Array2;
    }
    /**
     * Getter for warehouse name.
     * @return returns whName.
     */
    public String getwhName(){
        return whName;
    }
    /**
     * Getter for file name.
     * @return returns whFile.
     */
    public String getFile(){
        return whFile;
    }
}
    

    
