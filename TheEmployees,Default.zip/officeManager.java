package sample;

public class officeManager extends Employee{
    public officeManager(String a,String b,String c, String d,String e){
        super(a,b,c,d,e);
    }
}
