package sample;


public class WarehouseManager extends Employee {
    public WarehouseManager(String a, String b, String c, String d, String e) {
        super(a, b, c, d, e);
    }
}
