package sample;

public class SalesAssociate extends Employee {
    public SalesAssociate(String a, String b, String c, String d, String e) {
        super(a, b, c, d, e);
    }
}
