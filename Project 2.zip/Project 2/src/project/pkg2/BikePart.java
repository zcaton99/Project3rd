/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.pkg2;

import java.util.Comparator;
/**
 *
 * @author zachcaton
 */
public class BikePart {
    private String partName;
    private int partNumber;
    private double price;
    private double salePrice;
    private boolean onSale;
    private int quantity;
   
    /**
     * Constructor for BikePart class
     * @param partName
     * @param partNumber
     * @param price
     * @param salePrice
     * @param onSale 
     * @param quantity
     */
    public BikePart(String partName, int partNumber, double price, double salePrice, boolean onSale, int quantity){
       this.partName = partName;
       this.partNumber = partNumber;
       this.salePrice = salePrice;
       this.price = price;
       this.onSale = onSale;    
       this.quantity = quantity;
    }
    /**
     * Method for setting partName
     * @param pN
     */
    public void setpartName(String pN){
        partName = pN;
    }
    /**
     * Method for getting partName
     * @return partName
     */
    public String getpartName(){
        return partName;
    }
    /**
     * Method for setting partNumber
     * @param partNum
     */
    public void setpartNumber(int partNum){
        partNumber = partNum;
    }
    /**
     * Method for getting partNumber
     * @return parNumber
     */
    public int getpartNumber(){
        return partNumber;
    }
    /**
     * Method for setting price
     * @param pric
     */
    public void setprice(double pric){
        price = pric;
    }
    /**
     * Method for getting price
     * @return price
     */
    public double getprice(){
        return price;
    }
    /**
     * Method setting salePrice
     * @param salePric
     */
    public void setsalePrice(double salePric){
        salePrice = salePric;
    }
    /**
     * method getting salePrice
     * @return salePrice
     */
    public double getsalePrice(){
        return salePrice;
    }
    /**
     * Method setting onSale
     * @param onSal
     */
    public void setonSale(boolean onSal){
        onSale = onSal;
    }
    /**
     * Method getting onSale
     * @return onSale
     */
    public boolean getonSale(){
        return onSale;
    }
    /**
     * Method setting quantity
     * @param quant
     */        
    public void setquantity(int quant){
        quantity = quant;
    }
    /**
     * Method getting quantity
     * @return quantity
     */
    public int getquantity(){
        return quantity;
    }
    
    
    @Override
    public String toString(){
        return 
                partName + "," 
                + partNumber + ","
                + price + "," 
                + salePrice + "," 
                + onSale + "," 
                + quantity;
    }
    
    public static Comparator<BikePart> SORT_BY_NUMBER = new Comparator<BikePart>(){
       
        @Override
        public int compare(final BikePart b1, final BikePart b2) {
            return b1.partNumber - b2.partNumber;
        }
        
    };
    
    public static Comparator<BikePart> SORT_BY_PARTNAME = new Comparator<BikePart>(){
       
        @Override
        public int compare(final BikePart b1, final BikePart b2) {
            return b1.partName.compareTo(b2.partName);
        }
        
    };
    
    
}