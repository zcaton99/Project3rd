/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.pkg2;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author zachcaton
 */
public class Project2 extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
        launch(args);
        
        updateBpDs("wareHouseDB.txt");
        
    }
    
    //internal data struture
    public static ArrayList<BikePart> BpDs = new ArrayList<>();
    
    //update then added into certain spot in vans index
    public static ArrayList<BikePart> bp = new ArrayList<>();
    
    public static final ArrayList<BikePart>[] vans = new ArrayList[99];
    
    
    public static void movePartToVan(String pn, int pos){
        
        for(int i=0; i< BpDs.size(); i++){
            if(BpDs.get(i).getpartName().equals(pn)){
                if(bp.get(i).getpartName().equals(pn)){
                    bp.get(i).setprice(BpDs.get(i).getprice());
                    bp.get(i).setsalePrice(BpDs.get(i).getsalePrice());
                    bp.get(i).setonSale(BpDs.get(i).getonSale());
                    bp.get(i).setquantity(bp.get(i).getquantity()+1);
                }else{
                    bp.add(BpDs.get(i));
                }
            }
            
        }
        addToVan(pos);
        
    }
    
    public static void moveToAnotherVan(String pn, int first, int second){
        
        for(int i=0; i< vans.length; i++){
            
            if (vans[first].get(i).getpartName().equals(pn) && vans[second].get(i).getpartName().equals(pn)){
                vans[second].get(i).setprice(vans[first].get(i).getprice());
                vans[second].get(i).setsalePrice(vans[first].get(i).getsalePrice());
                vans[second].get(i).setonSale(vans[first].get(i).getonSale());
                vans[second].get(i).setquantity(vans[first].get(i).getquantity() + 1);
            }else{
                //vans[second].get(i).equals(vans[first].get(i));
                vans[second] = vans[first];
            }
            
        }
        
    }
    
    public static void addToVan(int position){
        for(int i=0; i < vans.length; i++){
            if(vans[i] == null){
                vans[position] = bp;
            }    
        }
    }
    
    public static BikePart findVanName(String name){
        
        for(BikePart b: bp){
            if(b.getpartName().equals(name)){
                return b;
            }
        }
        return null;
        
//        for(int i=0; i < vans.length; i++){
//            if(vans[pos].get(i).getpartName().equals(name)){
//                return vans[pos].get(i);
//            }
//           
//        }
//        return null;
 
    }
    
    public static void updateVan(String vanFile, int position) throws FileNotFoundException{
        File vf = new File(vanFile);
        Scanner inVF = new Scanner(vf);
        
        while(inVF.hasNext()){
            String line = inVF.nextLine();
            String [] pA = line.split(",");
            BikePart ba = new BikePart(pA[0], Integer.parseInt(pA[1]), Double.parseDouble(pA[2]), Double.parseDouble(pA[3]), Boolean.parseBoolean(pA[4]), Integer.parseInt(pA[5]));
            bp.add(ba);
            addToVan(position);

        }
        //bp = new ArrayList<>();
    }
    
    public static void writeVan(String vanFileName, int pos) throws FileNotFoundException{
        File vf = new File(vanFileName);
        try (PrintWriter vp = new PrintWriter(vf)) {
//            for(ArrayList<BikePart> va: vans){
//                vp.println(va.toString());
//            }
            for(int i=0; i < vans.length; i++){
                vp.println(vans[pos].get(i).toString());
            }
        }
    }
    
    /**
     * returns bikePart if name is same
     * @param name
     * @return 
     */
    public static BikePart findByName(String name){
        for(BikePart b: BpDs){
            if(b.getpartName().equals(name)){
                return b;
            } 
            
        }
        return null;
    }
    
    public static BikePart findbyNumber(int number){
        for(BikePart b: BpDs){
            if(b.getpartNumber() == number){
                return b;
            } 
            
        }
        return null;
    }
    
    
    /**
     * update / read in from file to internal DS
     * @param fileName
     * @throws FileNotFoundException 
     */
    public static void updateBpDs(String fileName) throws FileNotFoundException{
        File f = new File(fileName);
        Scanner in = new Scanner(f);
        while(in.hasNext()){
            String line = in.nextLine();
            String [] pA = line.split(",");
            BikePart b = new BikePart(pA[0], Integer.parseInt(pA[1]), Double.parseDouble(pA[2]), Double.parseDouble(pA[3]), Boolean.parseBoolean(pA[4]), Integer.parseInt(pA[5]));
            
            BikePart found = findByName(pA[0]);
            // if the adding part name is not in DB then adds the whole part to DB
            if(found == null){
                BpDs.add(b);
            }else{
                //if names are the same then updates the right parts
                found.setprice(b.getprice());
                found.setsalePrice(b.getsalePrice());
                found.setonSale(b.getonSale());
                found.setquantity(found.getquantity() + b.getquantity());
                
            }
        }
    }
    /**
     * write internal DS to file
     * @param fileName
     * @throws FileNotFoundException 
     */
    public static void writeBpDs(String fileName) throws FileNotFoundException{
        File f = new File(fileName);
        try (PrintWriter p = new PrintWriter(f)) {
            for(BikePart ds: BpDs){
                p.println(ds.toString());
            }
        }
    }
    
}
