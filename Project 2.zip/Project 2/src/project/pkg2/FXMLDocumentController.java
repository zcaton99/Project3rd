/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project.pkg2;

import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class FXMLDocumentController {

    @FXML
    private TextArea textArea;

    @FXML
    private TextField commandTextField;

    @FXML
    private Button submitButton;

    @FXML
    private TextField detailTextField;
    
    @FXML
    private TextField positionTextField;
    
    @FXML
    private TextField toAnotherPositionTextField;

    @FXML
    void submitButtonPressed(ActionEvent event) throws FileNotFoundException {
        String cmd = "";
        if (commandTextField.getText() != null){
            cmd = commandTextField.getText();
        }else{
           System.out.println("enter in commnad");
        }
        String dt = "";
        if(detailTextField.getText() != null){
            dt = detailTextField.getText();
        }
        String str = "";
        int pos = 0;
        if(positionTextField != null){
            str = positionTextField.getText();
            pos = Integer.parseInt(str);
        }else{
            
        }
        
        String sec = "";
        int pos2 = 0;
        if(toAnotherPositionTextField.getText() != null){
            sec = toAnotherPositionTextField.getText();
            pos2 = Integer.parseInt(sec);
        }else{
            
        }
        
        String comdOutput = "";
        
        switch(cmd.toLowerCase()){
            case "read":
                Project2.updateBpDs(dt);
                comdOutput = "Reading...";
                break;
            case "add van":
                Project2.updateVan(dt, pos);
                comdOutput = "Van was added";
                break;
            case "move part to van":
                Project2.movePartToVan(dt, pos);
                comdOutput = "Moved part to van";
                break;
            case "move van to other van":
                Project2.moveToAnotherVan(dt, pos, pos2);
                break;
            case "display":
                
                BikePart b = Project2.findByName(dt);
                
                if (b == null){
                    comdOutput = "Part not found";
                }else{
                    double price = b.getonSale() ? b.getsalePrice() : b.getprice();
                     comdOutput = "Part: " + b.getpartName() + " Price: " + price;
                }

                break;
            case "sell":
                int partNumber = Integer.parseInt(detailTextField.getText());
                BikePart c = Project2.findbyNumber(partNumber);
                String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
                
                if (c == null){
                        comdOutput = "part not found";
                }else{
                   if (c.getquantity() == 0 ){
                        comdOutput = "part out of stock";
                    }else{
                        int num = c.getquantity();
                        num = num - 1; 
                        c.setquantity(num);
                        if(c.getonSale() == true){
                            comdOutput = "SOLD: " + c.getpartName() + ", "+ c.getpartNumber()+ ", "+ c.getsalePrice() + ", " + timeStamp;
                        }else{
                            comdOutput = "SOLD: " + c.getpartName() + ", "+ c.getpartNumber()+ ", "+ c.getprice() + ", " + timeStamp;
                        }
                    }
                }
 
                break;
            case "sort by name":
                
                
                Collections.sort(Project2.BpDs, BikePart.SORT_BY_PARTNAME);
                for(int i=0; i < Project2.BpDs.size(); i++){
                    //System.out.println(Project2.BpDs.get(i).toString());
                    String out1 = Project2.BpDs.get(i).toString() + "\n";
                    textArea.appendText(out1);
                }

                break;
            case "sort van by name":
                Collections.sort(Project2.vans[pos], BikePart.SORT_BY_PARTNAME);
                
                for(int i=0; i < Project2.vans.length; i++){
                    String out1 = Project2.vans[pos].get(i).toString() + "\n";
                    textArea.appendText(out1);
                }
                
                break;
            case "sort by number":
                
                Collections.sort(Project2.BpDs, BikePart.SORT_BY_NUMBER);
                for(int i=0; i < Project2.BpDs.size(); i++){
                    String out = Project2.BpDs.get(i).toString() + "\n";
                    textArea.appendText(out);
                }
      
                break;
            case "sort van by number":
                Collections.sort(Project2.vans[pos], BikePart.SORT_BY_NUMBER);
                
                for(int i=0; i < Project2.vans.length; i++){
                    String out1 = Project2.vans[pos].get(i).toString() + "\n";
                    textArea.appendText(out1);
                }
                
                break;
            case "write van to file":
                Project2.writeVan(dt, pos);
                break;
            case "write warehouse to file":
                Project2.writeBpDs("wareHouseDB.txt");
                break;
            case "quit":
                
                break;
            default:
                //read file name
                comdOutput = "invalid command";
                break;
        }

        textArea.appendText(comdOutput + "\n");
        
        
    }

  
}
