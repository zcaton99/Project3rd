
package proj3;

/**
 * 
 * @author Josh
 */
public class officeManager extends Employee{
    public officeManager(String a,String b,String c, String d,String e){
        super(a,b,c,d,e);
    }
    
    
    /**
     * findByName compares all BikeParts in the warehouse data set and returns a BikePart if its name is equal to the name given.
     * @param name
     * @return returns BikePart b 
     */ 
    /*
    private static BikePart findByName(String name){
        for (BikePart b : bpDS) //bpDS is the static arraylist of bikeparts
            if (b.getName().equals(name))  
                    return b;
        return null;
    } 
    */

}
