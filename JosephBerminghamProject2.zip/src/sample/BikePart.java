package sample;

public class BikePart implements Comparable<BikePart> {
    private Double listPrice;
    private Double salePrice;
    private int partNumber;
    private String partName;
    private boolean onSale;
    private int number = 0;

    public BikePart(String name, int partNumber, double listPrice, double salePrice, boolean onSale, int number) {
        this.partName = name;
        this.partNumber = partNumber;
        this.listPrice = listPrice;
        this.salePrice = salePrice;
        this.onSale = onSale;
        this.number = number;
    }

    @Override
    public int compareTo(BikePart o) {
        if (this.getPartNumber() > o.getPartNumber()) {
            return -1;
        } else if (this.getPartNumber() < o.getPartNumber()) {
            return 1;
        } else
            return 0;
    }
public String partNumberToString(){
        Integer a=this.getPartNumber();
        return a.toString();
    }
    public String toString() {
        return this.partName + "," + this.partNumber + "," + this.listPrice + "," + this.salePrice + "," + this.onSale + "," + this.number;
    }

    public String specialToString() {
        return this.partName + "," + this.partNumber + "," + this.listPrice + "," + this.salePrice + "," + this.onSale;
    }

    public void setListPrice(Double listPrice) {
        this.listPrice = listPrice;
    }

    public Double getSalePrice() {
        return this.salePrice;
    }

    public void setSalePrice(Double salePrice) {
        this.salePrice = salePrice;
    }

    public int getPartNumber() {
        return this.partNumber;
    }

    public void setPartNumber(int partNumber) {
        this.partNumber = partNumber;
    }

    public String getPartName() {
        return this.partName;
    }

    public void setPartName(String partName) {
        this.partName = partName;
    }

    public boolean isOnSale() {
        return this.onSale;
    }

    public void setOnSale(boolean onSale) {
        this.onSale = onSale;
    }

    public Double getListPrice() {
        return this.listPrice;
    }

    public int getNumber() {
        return this.number;
    }

    public void setNumber(int a) {
        number += a;
        System.out.println();
    }

    public void superSetNumber(int a) {
        this.number = a;
    }
}

