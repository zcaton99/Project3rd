package sample;

import javafx.scene.control.TextArea;
import java.io.*;
import java.util.*;


public class Warehouse{

    private  PrintWriter writer = null;
    private ArrayList<String> inArray = new ArrayList<>();
    private String name;
    public Warehouse() {
        System.out.println("Creating Default Warehouse");
        try {
            name = "Warehousedb";
            writer = new PrintWriter(new FileWriter("Warehousedb.txt", true));
        } catch (java.io.FileNotFoundException e) {
            System.out.println("uhhhh");
        } catch (java.io.IOException d) {
            System.out.println("darn");
        }
    }

    public Warehouse(String name) {
        this.name = name;
        try {
            writer = new PrintWriter(new FileWriter(name + ".txt", true));
        } catch (java.io.FileNotFoundException e) {
            System.out.println("uhhhh");
        } catch (java.io.IOException d) {
            System.out.println("darn");
        }
        if(name.equals("Master")){
            ArrayList<Warehouse> wh=Controller.whArray;
            for (int i = 0; i < wh.size(); i++) {
                this.add("", false, (new File(wh.get(i).getName() + ".txt")));
            }
        }
    }

    public String getName() {
        return name;
    }
    public ArrayList<BikePart> getParts(){
        Scanner in = null;
        try {
            writer = new PrintWriter(new FileWriter(this.getName() + ".txt", true));
            in = new Scanner(new File(this.getName() + ".txt"));
        } catch (java.io.FileNotFoundException e) {
            System.out.println(e);
        } catch (java.io.IOException d) {
            System.out.println(d + "the");
        }
        ArrayList<BikePart> retArray = new ArrayList<>();
        while (in.hasNext()) {
            String t = in.nextLine();
            String[] broken = t.split(",");
            retArray.add(new BikePart(broken[0], Integer.parseInt(broken[1]), Double.parseDouble(broken[2]), Double.parseDouble(broken[3]), Boolean.parseBoolean(broken[4]), Integer.parseInt(broken[5])));
        }
        return retArray;
    }

    public String remove(int PartId, int quant) {
        Scanner in = null;

        try {
            writer = new PrintWriter(new FileWriter(this.getName() + ".txt", true));
            in = new Scanner(new File(this.getName() + ".txt"));
        } catch (java.io.FileNotFoundException e) {
            System.out.println(e);
        } catch (java.io.IOException d) {
            System.out.println(d + "the");
        }


        ArrayList<BikePart> remArray = new ArrayList<>();
        while (in.hasNext()) {
            String t = in.nextLine();
            String[] broken = t.split(",");
            remArray.add(new BikePart(broken[0], Integer.parseInt(broken[1]), Double.parseDouble(broken[2]), Double.parseDouble(broken[3]), Boolean.parseBoolean(broken[4]), Integer.parseInt(broken[5])));
        }
        for (int i = 0; i < remArray.size(); i++) {
            if (remArray.get(i).getPartNumber() == PartId) {

                int a = remArray.get(i).getNumber();
                System.out.println(a + " this is how many parts of type " + remArray.get(i).getPartName() + " i have");
                if (quant > a) {
                    System.out.println("you cant move that many parts");
                } else {
                    BikePart ret = new BikePart(remArray.get(i).getPartName(), remArray.get(i).getPartNumber(),remArray.get(i).getListPrice(),remArray.get(i).getSalePrice(),remArray.get(i).isOnSale(),remArray.get(i).getNumber());
                    //System.out.println(quant + "  this is the quantity remove is looking for");
                    ret.superSetNumber(quant);
                   // System.out.println(remArray.get(i).toString() + " this is remarray after i set the number");

                    remArray.get(i).superSetNumber(remArray.get(i).getNumber() - quant);
                    try {
                        writeToFile(remArray);
                    } catch (IOException e) {
                        System.out.println(e);
                    }
                    //System.out.println(ret.toString() + " this is what remove is returning");
                    return ret.toString();
                }
            }
        }
        return "";
    }
/*
* String args = if i am adding one part this is the full part seperated by commas
* boolean check is true iff i am adding one part (string args is not null)
* File a = the file i am adding to the warehouse if i am not adding a single string
* */
    public void add(String args, Boolean check, File a) {
        Scanner in = null;

        try {
            writer = new PrintWriter(new FileWriter(getName() + ".txt", true));
        } catch (java.io.FileNotFoundException e) {
            System.out.println("uhhhh");
        } catch (java.io.IOException d) {
            System.out.println("darn");
        }
        //if i am adding a single part i do this
        if (check) {
          //  System.out.println(args+" The argument passed to add");
            inArray.add(args);
            try {
                bikePartStore(inArray);
            } catch (IOException var11) {
                System.out.println(var11);
            }
            //if i am adding multiple parts i do this
        } else {
            try {
                in = new Scanner(a);
            } catch (java.io.FileNotFoundException e) {
                System.out.println("unexpected error");
            }

            inArray = new ArrayList();

            while (in.hasNext()) {
                inArray.add(in.nextLine());
            }

            try {
                bikePartStore(inArray);
            } catch (IOException var11) {
                System.out.println("io Exception");
            }
            /*
            * Either way i add the parts to an arraylist of Strings and pass that array to bikePartStore
            * */
        }
        writer.close();
    }

    /**
     * takes in an arraylist and uses the name of the thing to add the parts to the file then close it
     */
    private void bikePartStore(ArrayList<String> part) throws IOException {

        ArrayList<BikePart> db = new ArrayList();
        Scanner in = new Scanner(new File(this.getName() + ".txt"));
        /*
        *adds the database(File I am adding to) to an ArrayList to make it easier to add things
        */
        try {
            while (in.hasNext()) {
                String t = in.nextLine();
                // System.out.println(t + "       t");
                String[] broken = t.split(",");
                //Breaks the arraylist into an arraylist of BikeParts
                db.add(new BikePart(broken[0], Integer.parseInt(broken[1]), Double.parseDouble(broken[2]), Double.parseDouble(broken[3]), Boolean.parseBoolean(broken[4]), Integer.parseInt(broken[5])));
            }
        }catch(NullPointerException e){
            System.out.println("User Error, Please Consult Joseph Bermingham");
        }

        BikePart p;
        //This does what i did with the file i am going to add to. To the arraylist i am going to add to my file
        for (int i = 0; i < part.size(); i++) {
            //get next object in the array
            String t = part.get(i);

            //separate by comma's
            String[] broken = t.split(",");
            p = (new BikePart(broken[0], Integer.parseInt(broken[1]), Double.parseDouble(broken[2]), Double.parseDouble(broken[3]), Boolean.parseBoolean(broken[4]), Integer.parseInt(broken[5])));
            //Checks to make sure that db is not empty when i do this
            boolean fix = (!db.isEmpty());
            boolean a = false;
            //This whole for loop adds one bike part after searching for a matching part
            for (int j = 0; j < db.size(); j++) {
                boolean once = true;
                if (fix) {
                    for (int d = 0; d < db.size(); d++) {
                        if ((p.getPartName().equals(db.get(j).getPartName())) && once) {
                            db.get(j).setNumber(p.getNumber());
                            //System.out.println(p.getNumber()+" P.getNumber");
                            db.get(j).setOnSale(p.isOnSale());
                            db.get(j).setListPrice(p.getListPrice());
                            db.get(j).setSalePrice(p.getSalePrice());
                            a = true;
                            //once makes sure that i add a part only once, helps reduce multipul parts
                            once = false;
                        }
                    }
                }

            }
            if (!a) {
                db.add(p);
            }
        }//write to file closes the file for me
        writeToFile(db);
    }
    /**
     * @return returns a string of the specified bike part
     */

    public String show() {
        System.out.println("Would you like to look for a part my 1)name or 2)number");
        Scanner in = new Scanner(System.in);
        Scanner see = null;
        ArrayList<BikePart> help = new ArrayList<>();
        String is = "there is no item by that description";

        try {
            see = new Scanner(new File(name + ".txt"));
        } catch (java.io.FileNotFoundException e) {
            System.out.println("whoops");
        }

        while (see.hasNext()) {
            String t = see.nextLine();
            String[] broken = t.split(",");
            BikePart p = (new BikePart(broken[0], Integer.parseInt(broken[1]), Double.parseDouble(broken[2]), Double.parseDouble(broken[3]), Boolean.parseBoolean(broken[4]), Integer.parseInt(broken[5])));
            help.add(p);
        }

        int bob = in.nextInt();
        while (bob >= 3 || bob <= 0) {
            System.out.println("non valid number please pick one for a name or two for a number");
            bob = in.nextInt();
        }

        Double iffy = 0.0;
        if (bob == 1) {
            in.nextLine();
            System.out.println("please enter the name of the part you wish to display");
            String check = in.nextLine();
            // System.out.println(check + "check");
            for (int i = 0; i < help.size(); i++) {
                if (help.get(i).getPartName().equalsIgnoreCase(check)) {
                    if (help.get(i).isOnSale())
                        iffy = help.get(i).getSalePrice();
                    else
                        iffy = help.get(i).getListPrice();

                    is = (help.get(i).getPartName() + ", " + iffy);
                }
            }

        }
        if (bob == 2) {
            System.out.println("Please enter the number of the part you wish to display");
            int check = in.nextInt();
            for (int i = 0; i < help.size(); i++) {
                if (help.get(i).getPartNumber() == check) {
                    if (help.get(i).isOnSale())
                        iffy = help.get(i).getSalePrice();
                    else
                        iffy = help.get(i).getListPrice();

                    is = (help.get(i).getPartName() + ", " + iffy);
                }
            }
        }
        return is;
    }

    public String sell(int id, TextArea a, int quant) throws java.io.FileNotFoundException {
        ArrayList<BikePart> db = new ArrayList();
        Scanner in = new Scanner(new File(name + ".txt"));

        /*
        *adds the database to an ArrayList to make it easier to add things
        */
        while (in.hasNext()) {
            String t = in.nextLine();
            String[] broken = t.split(",");
            db.add(new BikePart(broken[0], Integer.parseInt(broken[1]), Double.parseDouble(broken[2]), Double.parseDouble(broken[3]), Boolean.parseBoolean(broken[4]), Integer.parseInt(broken[5])));
        }
        Scanner check = new Scanner(System.in);
        int target = 0;
        boolean hit = false;
        while (hit == false) {
            for (int i = 0; i < db.size(); i++) {
                if (db.get(i).getPartNumber() == id) {
                    target = i;
                    hit = true;
                }
            }
            if (hit == false) {
                return "that part id is not in this file. please enter a different part id";
            }
        }
        a.appendText("you have " + db.get(target).getNumber() + " of the part " + db.get(target).getPartName() + "\n");
        int toSell = quant;
        if (toSell > db.get(target).getNumber()) {
            return ("you don't have that many of that part you can sell up to " + db.get(target).getNumber() + "\n");
        }
        db.get(target).setNumber(toSell - (toSell * 2));
        try {
            writeToFile(db);
        } catch (IOException e) {
            System.out.println(e);
        }
        String time = java.time.LocalTime.now().toString();
        double cat;
        String onSale;
        if (db.get(target).isOnSale()) {
            cat = db.get(target).getSalePrice();

        } else {
            cat = db.get(target).getListPrice();

        }

        return "You have sold " + toSell + " of the part " + db.get(target).getPartName() + "\n" + " at " + time + " for $" + cat * toSell + " you have " + db.get(target).getNumber() + " left\n";
    }

    public String sortAleph() throws FileNotFoundException {
        Scanner in = new Scanner(new File(name + ".txt"));
        //takes in the array and puts it all into sortable
        ArrayList<BikePart> sortable = new ArrayList<>();
        while (in.hasNext()) {
            String t = in.nextLine();
            String[] broken = t.split(",");
            sortable.add(new BikePart(broken[0], Integer.parseInt(broken[1]), Double.parseDouble(broken[2]), Double.parseDouble(broken[3]), Boolean.parseBoolean(broken[4]), Integer.parseInt(broken[5])));
        }

        int n = sortable.size();
        //takes sortable and puts it into an array called sort, i did this because i was having infinite loop problems
        BikePart[] sort = new BikePart[n];
        for (int o = 0; o < sort.length; o++) {
            BikePart par = new BikePart(sortable.get(o).getPartName(), sortable.get(o).getPartNumber(), sortable.get(o).getListPrice(), sortable.get(o).getSalePrice(), sortable.get(o).isOnSale(), sortable.get(o).getNumber());
            sort[o] = par;
        }

        //this does the actual sorting compare to returns an int, i believe i used a bubble sort, but honestly i am unsure
        for (int m = 0; m < sort.length; m++) {
            for (int i = 0; i < sort.length - 1; i++) {
                BikePart temp = sort[m];
                if (m == i) continue;
                int x = temp.getPartName().compareToIgnoreCase(sort[i].getPartName());
                if (x < 0) {
                    temp = sort[i];
                    sort[i] = sort[m];
                    sort[m] = temp;
                }
            }
        }
        //adds all of the now sorted values into a String called out. these values are never actually saved, dont know if im supposed to do that
        String out = "";
        for (int o = 0; o < sortable.size(); o++) {
            out += sort[o].toString() + "\n";
        }
        return out;
    }

    public String sortId() throws FileNotFoundException {
        Scanner in = new Scanner(new File(name + ".txt"));
        ArrayList<BikePart> sortable = new ArrayList<>();
        while (in.hasNext()) {
            String t = in.nextLine();
            String[] broken = t.split(",");
            sortable.add(new BikePart(broken[0], Integer.parseInt(broken[1]), Double.parseDouble(broken[2]), Double.parseDouble(broken[3]), Boolean.parseBoolean(broken[4]), Integer.parseInt(broken[5])));
        }
      /* int n = sortable.size();
        //takes sortable and puts it into an array called sort, i did this because i was having infinite loop problems
        BikePart[] sort = new BikePart[n];
        for (int o = 0; o < sort.length; o++) {
           //BikePart par = new BikePart(sortable.get(o).getPartName(), sortable.get(o).getPartNumber(), sortable.get(o).getListPrice(), sortable.get(o).getSalePrice(), sortable.get(o).isOnSale(), sortable.get(o).getNumber());
            BikePart par =sortable.get(o);
            sort[o] = par;
        }
        // System.out.println(sortable.size() + "Size");
        for (int t = 0; t < sort.length; t++) {
            for (int i = 1; i < sort.length - 1; i++) {
                if (sort[t].getPartNumber() < sort[i].getPartNumber()) {
                    BikePart temp = sort[i];
                    sort[i] = sort[t];
                    sort[t] = temp;
                }
            }
        }*/
      Collections.sort(sortable,BY_NUMBER);

        String out = "";
        for (int o = 0; o < sortable.size(); o++) {
            out += sortable.get(o).toString() + "\n";
        }
        return out;
    }

    static final Comparator<BikePart> BY_NUMBER=new Comparator<BikePart>(){
        public int compare(BikePart p1,BikePart p2){
            int p = p2.getPartNumber();

            return p1.partNumberToString().compareTo(p2.partNumberToString());}
};

    private void writeToFile(ArrayList<BikePart> db) throws IOException {
        writer = new PrintWriter(new FileWriter(this.name + ".txt"));
        PrintWriter masterWriter = new PrintWriter(new FileWriter("Master.txt"));
        //  System.out.println(db.size() + "      Size at adding");
        for (int h = 0; h < db.size(); h++) {
            writer.println(db.get(h).toString());
            masterWriter.println(db.get(h).toString());
            //  System.out.println(db.get(h).toString() + "     the Things added to writer");
        }
        //System.out.println("WRITETOFILE");
        writer.close();
        masterWriter.close();
    }


}