package sample;
public class salesVan extends Warehouse {
    private  String name;
    public salesVan(String name){
        super(name);
    }
}
