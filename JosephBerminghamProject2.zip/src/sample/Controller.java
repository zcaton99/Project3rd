package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Scanner;

public class Controller {
    @FXML
    public TextField TextToBeProccessed;
    public static ArrayList<Warehouse> whArray = new ArrayList<>();
    public static int a = 0;
    private static Warehouse master = null;
    @FXML
    private ResourceBundle resources;
    @FXML
    private URL location;
    @FXML
    public TextArea DisplayField;
    @FXML
    private TextField SalesVanName;
    @FXML
    private TextField MoveFromWarehouse;
    @FXML
    private TextField MovePartNumber;
    @FXML
    private TextField MoveToWarehouse;
    @FXML
    private TextField WarehouseSell;
    @FXML
    private TextField SellPartNumber;
    @FXML
    private TextField DisplayWarehouse;
    @FXML
    private Button DisplayByNumberButton;
    @FXML
    private TextField WarehouseToAdd;
    @FXML
    private TextField PartToAdd;
    @FXML
    private TextField SellPartQuantity;
    @FXML
    private TextField MovePartQuant;
    @FXML
    private Button DisplayPart;
    @FXML
    private TextField PartToDisplay;

    @FXML
    void DisplayPart(ActionEvent event) {
        addDefault();
        String find = PartToDisplay.getText();
        for (int i = 0; i < whArray.size(); i++) {
            for (int g = 0; g < whArray.get(i).getParts().size(); g++) {
                ArrayList<BikePart> checkarr = whArray.get(i).getParts();
                if (find.equalsIgnoreCase(checkarr.get(g).getPartName())) {
                    DisplayField.appendText(checkarr.get(g).specialToString() + "\n");
                }
            }
        }

    }

    @FXML
    void AddPart(ActionEvent event) {
        try {
            addDefault();
            System.out.println("Entering AddPart");
            String Wearhouse = WarehouseToAdd.getText();
            String Part = PartToAdd.getText();
            int passPart = Integer.MAX_VALUE;
//adding part to the warehouse, and keeping track of where in the whArray the added to warehouse is
            for (int i = 0; i < whArray.size(); i++) {
                if (Wearhouse.equalsIgnoreCase(whArray.get(i).getName())) {
                    whArray.get(i).add(Part, true, null);
                    passPart = i;
                }

            }
            String[] broken = Part.split(",");
            BikePart check = new BikePart(broken[0], Integer.parseInt(broken[1]), Double.parseDouble(broken[2]), Double.parseDouble(broken[3]), Boolean.parseBoolean(broken[4]), 0);

            for (int i = 0; i < whArray.size(); i++) {
                for (int g = 0; g < whArray.get(i).getParts().size(); g++) {
                    ArrayList<BikePart> checkarr = whArray.get(i).getParts();
                    //System.out.println(checkarr.get(g).toString()+"CONTROLLER_ADD_PART");

                    if (checkarr.get(g).getPartNumber() == check.getPartNumber() && checkarr.get(g).getPartName().equalsIgnoreCase(check.getPartName()) && i != passPart) {
                        check.superSetNumber(0);
                        //System.out.println(check.toString() + " check.toString()");
                        whArray.get(i).add(check.toString(), true, null);
                    }
                }
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            DisplayField.appendText("User Error Please consult Joseph Bermingham\n");
        }
    }

    @FXML
    /**
     * creates a sales van with the specified name
     */
    void CreateSalesVan(ActionEvent event) {
        String salesVanName = SalesVanName.getText();
        whArray.add(new salesVan(salesVanName));
        DisplayField.appendText("sales Van " + salesVanName + " has been created\n");

    }

    /**
     * displays parts in a sales van, the warehouse, or all of the sales vans and warehouses in alphabetical order depending on the entered things
     */

    @FXML
    void DisplayByName(ActionEvent event) {
        addDefault();
        System.out.println(DisplayWarehouse.getText() + " CONTROLLER_DISPLAY_BY_NAME");
        for (int i = 0; i < whArray.size(); i++) {
            //System.out.println(whArray.get(i).getName() + " " + i);
            if (DisplayWarehouse.getText().equalsIgnoreCase(whArray.get(i).getName())) {
                try {
                    DisplayField.appendText(whArray.get(i).sortAleph() + "\n");
                } catch (FileNotFoundException e) {
                    System.out.println(e);
                    DisplayField.appendText("Warehouse Not Found");
                }
            }
        }
        //checking that i dont add the same thing twice
        ArrayList<String> checker = new ArrayList<>();
        boolean repeat = false;


        if (DisplayWarehouse.getText().equals("") && a == 0) {
            master = new Warehouse("Master");
            a++;
        }
        if (DisplayWarehouse.getText().equals("")) {
            try {
                DisplayField.appendText(master.sortAleph() + "\n");
                //  System.out.println(main.sortId());
            } catch (FileNotFoundException e) {
                System.out.println(e);
            }
        }
    }


    @FXML
    void DisplayByNumber(ActionEvent event) {
        addDefault();

        for (int i = 0; i < whArray.size(); i++) {
            if (DisplayWarehouse.getText().equalsIgnoreCase(whArray.get(i).getName())) {
                try {
                    DisplayField.appendText(whArray.get(i).sortId() + "\n");
                } catch (FileNotFoundException e) {
                    System.out.println(e);
                }
            }
        }

        if (DisplayWarehouse.getText().equals("") && a == 0) {
            master = new Warehouse("Master");
            a++;
        }
        if (DisplayWarehouse.getText().equals("")) {
            try {
                DisplayField.appendText(master.sortId() + "\n");
                //  System.out.println(main.sortId());
            } catch (FileNotFoundException e) {
                System.out.println(e);
            }
        }
    }

    @FXML
    void MovePart(ActionEvent event) {
        try {
            addDefault();
            String from = MoveFromWarehouse.getText();
            String to = MoveToWarehouse.getText();
            int id = Integer.parseInt(MovePartNumber.getText());
            int quant = Integer.parseInt(MovePartQuant.getText());
            String part = "";
            boolean pass = false;
            for (int i = 0; i < whArray.size(); i++) {
                if (whArray.get(i).getName().equalsIgnoreCase(from))
                    part = whArray.get(i).remove(id, quant);
                pass = true;
            }
            System.out.println(part + " what i am trying to add to the thing");
            int reg = Integer.MAX_VALUE;
            for (int i = 0; i < whArray.size(); i++) {
                if (pass && whArray.get(i).getName().equalsIgnoreCase(to)) {
                    System.out.println(whArray.get(i).getName());
                    whArray.get(i).add(part, true, null);
                    reg = i;
                }
            }
            DisplayField.appendText(part.toString() + "\n Was added to Warehouse \n" + whArray.get(reg).getName());

        } catch (NumberFormatException e) {
            DisplayField.appendText("User Error Please Consult Joseph Bermingham\n");
        }
    }

    @FXML
    void ProccessToWarehouse(ActionEvent event) {
        String file;
        boolean bob = true;
        File inFile = null;

        try {
            file = TextToBeProccessed.getText();

            inFile = new File(file);
            Scanner in = new Scanner(inFile);
        } catch (IOException e) {
            DisplayField.appendText("non Valid File Name\nplease try again\n");
            bob = false;
        }
        if (bob) {
            Warehouse main = new Warehouse();
            main.add("", false, inFile);
        }
    }


    @FXML
    void SellPart(ActionEvent event) {
        try {
            String wh = WarehouseSell.getText();
            Warehouse main = new Warehouse();
            whArray.add(main);
            int quant = Integer.parseInt(SellPartQuantity.getText());
            int part = Integer.parseInt(SellPartNumber.getText());
            for (int i = 0; i < whArray.size(); i++) {
                System.out.println(whArray.get(i).getName() + " name " + i + " in array");
                if (whArray.get(i).getName().equalsIgnoreCase(wh)) {
                    try {
                        DisplayField.appendText(whArray.get(i).sell(part, DisplayField, quant));
                    } catch (FileNotFoundException e) {
                        System.out.println(e);
                    }

                }
            }
        } catch (NumberFormatException e) {
            DisplayField.appendText("user error please consult Joseph Bermingham\n");
        }
    }

    void addDefault() {
        boolean pass = false;
        for (int i = 0; i < whArray.size(); i++) {
            if (whArray.get(i).getName().equals("Warehousedb"))
                pass = true;
        }
        if (!pass) {
            whArray.add(new Warehouse());
        }
    }

    @FXML
    void initialize() {
        assert TextToBeProccessed != null : "fx:id=\"TextToBeProccessed\" was not injected: check your FXML file 'sample.fxml'.";
        assert DisplayField != null : "fx:id=\"DisplayField\" was not injected: check your FXML file 'sample.fxml'.";
        assert SalesVanName != null : "fx:id=\"SalesVanName\" was not injected: check your FXML file 'sample.fxml'.";
        assert MoveFromWarehouse != null : "fx:id=\"MoveFromWarehouse\" was not injected: check your FXML file 'sample.fxml'.";
        assert MovePartNumber != null : "fx:id=\"MovePartNumber\" was not injected: check your FXML file 'sample.fxml'.";
        assert MoveToWarehouse != null : "fx:id=\"MoveToWarehouse\" was not injected: check your FXML file 'sample.fxml'.";
        assert WarehouseSell != null : "fx:id=\"WarehouseSell\" was not injected: check your FXML file 'sample.fxml'.";
        assert SellPartNumber != null : "fx:id=\"SellPartNumber\" was not injected: check your FXML file 'sample.fxml'.";
        assert DisplayWarehouse != null : "fx:id=\"DisplayWarehouse\" was not injected: check your FXML file 'sample.fxml'.";
        assert DisplayByNumberButton != null : "fx:id=\"DisplayByNumberButton\" was not injected: check your FXML file 'sample.fxml'.";
        assert WarehouseToAdd != null : "fx:id=\"WarehouseToAdd\" was not injected: check your FXML file 'sample.fxml'.";
        assert PartToAdd != null : "fx:id=\"PartToAdd\" was not injected: check your FXML file 'sample.fxml'.";

    }
}
